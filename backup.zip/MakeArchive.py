import shutil
archive_name = shutil.make_archive('backup', 'zip')